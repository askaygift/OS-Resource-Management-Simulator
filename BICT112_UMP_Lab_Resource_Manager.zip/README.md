# UMP Lab Resource Manager

An interactive operating-system laboratory simulator built with **HTML, CSS, and JavaScript only**. It demonstrates how RAM, CPU time, devices, files, and jobs work together.

## Run the complete website

The project includes a small JavaScript backend using Node's built-in `http` module. No packages or build step are required.

```bash
node server.js
```

Open `http://localhost:8080`.

You can also open `index.html` directly, but the backend API and reliable multi-page routing are available when the server is running.

## Project structure

```text
index.html            Dashboard entry page
pages/*.html          Separate pages for every major area
css/style.css         Shared visual system and responsive layout
js/engine.js          DOM-free simulation engine and calculations
js/app.js             UI rendering, actions, navigation, alerts, save/load
js/tests.js            18 automated browser-safe engine scenarios
server.js              JavaScript backend and static file server
docs/*.txt             Readable downloadable project documentation
docs/system-architecture.drawio  Draw.io system architecture diagram
```

## Pages and features

| Page | Purpose |
| --- | --- |
| Dashboard | Live memory, CPU, jobs, devices, chart, and recent jobs |
| Jobs | Submit, edit, complete, delete, and clear jobs |
| Processes | Process states, ready queue, and process control blocks |
| Memory | Dynamic RAM partitions, First-Fit / Best-Fit, deallocation, split, merge, and compaction |
| Scheduler | FCFS, SJF, Round Robin, Priority, Gantt timeline, and metrics |
| Devices | Device availability, exclusive ownership, queues, add/remove |
| Files | Create, edit, delete, and file locking |
| Analytics | Fragmentation, rejection rate, throughput, and timings |
| Tests | Run all 19 automated calculation/lifecycle tests |
| Event log | Readable explanation of simulator decisions |
| Save & load | Download and reload readable `.txt` session reports |
| Guide | Plain-language explanation of the concepts |

## Important behaviour

- **Auto-run:** 1x, 2x, and 5x speeds are available. Auto-run can be paused and automatically stops when all jobs reach a final state.
- **Random demo:** resets safely, generates fitting random jobs, changes scheduling and memory policies, assigns resources, and advances the simulation automatically. The status pill, dashboard, Gantt chart, and Event log show every movement.
- **Alerts:** Every success or validation error appears in the accessible live toast area.
- **Calculations:** Metrics are derived from the current simulation state, not hard-coded display values.
- **Persistence:** The browser autosaves the current session in `localStorage` and the user can export/import a readable text file.
- **Backend live data:** `/api/health`, `/api/project-info`, and `/api/time` expose real data from the running JavaScript server.

## Backend endpoints

- `GET /api/health` - server health and start time.
- `GET /api/project-info` - project metadata, supported languages, pages, and features.
- `GET /api/time` - current ISO time and Unix timestamp.

See [`docs/BACKEND_API.txt`](docs/BACKEND_API.txt) for details.

## Verification

The engine was syntax-checked and all **19 / 19** automated scenarios passed, including allocation, rejection, scheduling, device queues, file locking, compaction, and end-to-end execution.

See [`docs/USER_GUIDE.txt`](docs/USER_GUIDE.txt), [`docs/PROJECT_OVERVIEW.txt`](docs/PROJECT_OVERVIEW.txt), and [`docs/CHANGELOG.txt`](docs/CHANGELOG.txt) for the readable project documentation.

/**
 * tests.js - 19 automated scenarios for the assignment test evidence.
 * Every test builds a brand-new engine, performs actions, then checks the result.
 */
const GB = 1024;
const fresh = (total = 16384, opts = {}) => { const e = UMOS.createEngine(total); Object.entries(opts).forEach(([k, v]) => e.set(k, v)); return e; };
const add = (e, o = {}) => e.submit({ name: 'Job', memMb: 512, burst: 3, ...o });
const jobOf = (e, n) => e.state.jobs[n - 1];
const blockFor = (e, id) => e.state.blocks.find(b => b.jobId === id);

const TESTS = [
  { name: 'Valid job submission', category: 'Jobs', input: 'Name=Job, Memory=512 MB, Burst=3 s', expected: 'Job admitted and set to READY.',
    run: () => { const e = fresh(); return add(e).ok && jobOf(e, 1).state === 'READY'; } },
  { name: 'Blank job name rejected', category: 'Validation', input: 'Name=blank, Memory=512 MB, Burst=3 s', expected: 'Submission rejected because the job name is blank.',
    run: () => { const e = fresh(); return !add(e, { name: '   ' }).ok && e.state.jobs.length === 0; } },
  { name: 'Invalid job size', category: 'Validation', input: 'Memory=0 MB', expected: 'Submission rejected because memory must be greater than 0.',
    run: () => { const e = fresh(); const result = add(e, { memMb: 0 }); return result.ok === false; } },
  { name: 'Dynamic memory allocation', category: 'Memory', input: 'RAM=1000 MB, J1=300 MB', expected: 'J1 receives 300 MB and the remaining 700 MB becomes a free hole.',
    run: () => { const e = fresh(1000); add(e, { memMb: 300 }); return e.state.blocks.length === 2 && blockFor(e, 'JOB-001').size === 300 && e.state.blocks[1].size === 700 && !e.state.blocks[1].jobId; } },
  { name: 'First-Fit', category: 'Memory', input: 'RAM=1200 MB; holes=500 MB and 400 MB; request=350 MB', expected: 'First-Fit selects the first suitable 500 MB hole.',
    run: () => { const e = fresh(1200); add(e, { memMb: 500 }); add(e, { memMb: 100 }); add(e, { memMb: 400 }); add(e, { memMb: 200 }); e.complete('JOB-001'); e.complete('JOB-003'); add(e, { memMb: 350 }); return blockFor(e, 'JOB-005')?.start === 0 && blockFor(e, 'JOB-005')?.size === 350; } },
  { name: 'Best-Fit', category: 'Memory', input: 'Same holes as First-Fit; request=350 MB', expected: 'Best-Fit selects the smaller suitable 400 MB hole.',
    run: () => { const e = fresh(1200, { memAlgo: 'BEST_FIT' }); add(e, { memMb: 500 }); add(e, { memMb: 100 }); add(e, { memMb: 400 }); add(e, { memMb: 200 }); e.complete('JOB-001'); e.complete('JOB-003'); add(e, { memMb: 350 }); return blockFor(e, 'JOB-005')?.start === 600 && blockFor(e, 'JOB-005')?.size === 350; } },
  { name: 'Remaining free portion', category: 'Memory', input: 'RAM=1000 MB, J1=300 MB', expected: 'A separate 700 MB free block remains.',
    run: () => { const e = fresh(1000); add(e, { memMb: 300 }); return e.state.blocks.some(b => !b.jobId && b.size === 700 && b.start === 300); } },
  { name: 'External fragmentation', category: 'Memory', input: 'RAM=1000 MB; holes=300 MB and 300 MB; request=500 MB', expected: 'Job is rejected because 600 MB is free in total but the largest contiguous hole is 300 MB.',
    run: () => { const e = fresh(1000); add(e, { memMb: 300 }); add(e, { memMb: 300 }); add(e, { memMb: 100 }); e.complete('JOB-001'); return !add(e, { memMb: 500 }).ok && e.state.blocks.filter(b => !b.jobId).reduce((t,b)=>t+b.size,0) === 600; } },
  { name: 'Automatic deallocation and merging', category: 'Memory', input: 'RAM=1000 MB; J1=300 MB, J2=200 MB, then complete both', expected: 'Adjacent free areas join back into one 1000 MB free block.',
    run: () => { const e = fresh(1000); add(e, { memMb: 300 }); add(e, { memMb: 200 }); e.complete('JOB-001'); e.complete('JOB-002'); return e.state.blocks.length === 1 && !e.state.blocks[0].jobId && e.state.blocks[0].size === 1000; } },
  { name: 'Manual split of a free hole', category: 'Memory', input: 'Split a 1000 MB free block at 400 MB', expected: 'Two adjacent free blocks of 400 MB and 600 MB are created.',
    run: () => { const e = fresh(1000); return e.split(1, 400).ok && e.state.blocks.length === 2 && e.state.blocks[0].size === 400 && e.state.blocks[1].size === 600; } },
  { name: 'FCFS scheduling', category: 'CPU', input: 'Two jobs with bursts 3 s and 1 s, FCFS', expected: 'Earliest arrival runs first.',
    run: () => { const e = fresh(); add(e, { burst: 3 }); add(e, { burst: 1 }); e.step(); return jobOf(e, 1).state === 'RUNNING'; } },
  { name: 'Round Robin quantum', category: 'CPU', input: 'Two jobs, quantum=1 s', expected: 'A running job is pre-empted after its quantum when another job is READY.',
    run: () => { const e = fresh(4096, { cpuAlgo: 'ROUND_ROBIN', quantum: 1 }); add(e, { burst: 3 }); add(e, { burst: 3 }); e.step(); return jobOf(e, 1).state === 'READY'; } },
  { name: 'Wait on busy device', category: 'Process', input: 'Two jobs request PRINTER', expected: 'The competing job moves to WAITING.',
    run: () => { const e = fresh(4096, { cpuAlgo: 'ROUND_ROBIN', quantum: 1 }); add(e, { device: 'PRINTER' }); add(e, { device: 'PRINTER' }); e.step(); e.step(); return jobOf(e, 2).state === 'WAITING'; } },
  { name: 'Device mutual exclusion', category: 'Device', input: 'One job requests PRINTER', expected: 'Printer is held by exactly one job.',
    run: () => { const e = fresh(); add(e, { device: 'PRINTER' }); e.step(); return e.state.devices[0].holder === 'JOB-001'; } },
  { name: 'Device FIFO queue', category: 'Device', input: 'Three jobs request PRINTER', expected: 'Waiting jobs queue in arrival order.',
    run: () => { const e = fresh(4096, { cpuAlgo: 'ROUND_ROBIN', quantum: 1 }); [1,2,3].forEach(() => add(e, { device: 'PRINTER' })); e.step(); e.step(); return e.state.devices[0].queue.join() === 'JOB-002,JOB-003'; } },
  { name: 'Device release and handoff', category: 'Device', input: 'Three queued printer jobs', expected: 'Freed printer goes to the next waiting job.',
    run: () => { const e = fresh(4096, { cpuAlgo: 'ROUND_ROBIN', quantum: 1 }); [1,2,3].forEach(() => add(e, { device: 'PRINTER' })); [1,2,3].forEach(() => e.step()); return e.state.devices[0].holder === 'JOB-002' && jobOf(e, 2).state === 'READY'; } },
  { name: 'File creation', category: 'File', input: 'Create notes.txt twice', expected: 'First creation succeeds; duplicate is refused.',
    run: () => { const e = fresh(); const n = e.state.files.length; return e.createFile('notes.txt', 5).ok && e.state.files.length === n + 1 && !e.createFile('NOTES.txt', 1).ok; } },
  { name: 'File access and locking', category: 'File', input: 'Job opens lab_dataset.csv', expected: 'File is locked while in use and cannot be deleted.',
    run: () => { const e = fresh(); add(e, { file: 'lab_dataset.csv', burst: 3 }); e.step(); return e.state.files[2].holder === 'JOB-001' && !e.deleteFile('lab_dataset.csv').ok; } },
  { name: 'End-to-end execution', category: 'Simulation', input: 'Submit J1=512 MB, burst=2 s; run 2 steps', expected: 'Job terminates and its memory is freed.',
    run: () => { const e = fresh(); add(e, { memMb: 512, burst: 2 }); e.step(); e.step(); return jobOf(e, 1).state === 'TERMINATED' && e.stats().used === 0 && e.state.blocks.length === 1 && e.state.blocks[0].size === 16384; } },
];

function runAllTests() {
  return TESTS.map(t => { let pass = false, actual = ''; try { pass = !!t.run(); actual = pass ? 'Observed expected behaviour.' : 'Observed behaviour did not match the expected result.'; } catch (err) { actual = `Test threw an error: ${err.message}`; } return { ...t, pass, actual }; });
}

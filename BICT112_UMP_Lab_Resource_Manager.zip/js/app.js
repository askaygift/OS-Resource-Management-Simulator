/**
 * app.js - User interface layer.
 * Flow: click -> engine method -> engine emits -> render() redraws every page.
 * Sections: helpers, renderers (one per page), dialogs, actions, wiring, start-up.
 */
(() => {
  const $ = sel => document.querySelector(sel);
  const RAM_OPTIONS = [4096, 8192, 16384, 32768, 65536];
  const PRESETS = [
    { label: 'Report (1 GB)', name: 'Student report', mem: 1, unit: 'GB', burst: 4, priority: 2, device: 'PRINTER', file: 'student_report.pdf' },
    { label: 'Compile (2 GB)', name: 'Java compile', mem: 2, unit: 'GB', burst: 3, priority: 1, device: 'NONE', file: 'lab_assignment.java' },
    { label: 'Data query (4 GB)', name: 'Data query', mem: 4, unit: 'GB', burst: 6, priority: 3, device: 'DISK', file: 'lab_dataset.csv' },
    { label: 'Virtual machine (6 GB)', name: 'Virtual machine', mem: 6, unit: 'GB', burst: 8, priority: 2, device: 'DISK', file: 'NONE' },
  ];
  const STORE_KEY = 'ump-os-sim-v3';
  const DONE = ['TERMINATED', 'REJECTED'];

  const os = UMOS.createEngine(16384);
  const s = os.state;
  let chartMode = 'used', timer = null, runMode = 'idle', randomTick = 0;

  // ---------- helpers ----------
  const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const badge = st => `<span class="badge ${st}">${st}</span>`;
  const color = id => `hsl(${(parseInt(id.slice(4), 10) * 67) % 360} 65% 52%)`;
  const btn = (act, id, label, cls = '') => `<button class="btn sm ${cls}" data-act="${act}" data-id="${esc(id)}">${label}</button>`;
  const table = (head, rows, empty) =>
    `<thead><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>` +
    (rows.length ? rows.join('') : `<tr><td class="empty" colspan="${head.length}">${empty}</td></tr>`) + '</tbody>';
  const statCard = (label, value, note = '') => `<div class="card"><h3>${label}</h3><div class="big">${value}</div><p>${note}</p></div>`;
  const holds = j => [...s.devices, ...s.files].filter(r => r.holder === j.id).map(r => esc(r.name)).join(', ') || '-';

  let toastTimer;
  function toast(res) {
    const t = $('#toast');
    t.textContent = res.msg; t.classList.toggle('err', !res.ok); t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
  }

  // ---------- renderers ----------
  function renderOverview(st) {
    const pct = Math.round((st.used / s.totalMb) * 100), run = s.jobs.find(j => j.state === 'RUNNING');
    $('#ovMem').textContent = os.fmt(st.used);
    $('#ovMemBar').style.width = pct + '%';
    $('#ovMemSub').textContent = `${pct}% of ${os.fmt(s.totalMb)} - ${os.fmt(st.free)} free`;
    $('#ovCpu').textContent = run ? run.id : 'Idle';
    $('#ovCpuSub').textContent = `${s.cpuAlgo.replace('_', ' ')} - ${st.cpuUtil}% busy`;
    $('#ovJobs').textContent = s.jobs.filter(j => !DONE.includes(j.state)).length + ' active';
    $('#ovJobsSub').textContent = `${st.done} completed - ${s.jobs.length} total`;
    $('#tick').textContent = `T = ${s.tick}s`;
    const status = $('#runStatus');
    if (status) status.textContent = runMode === 'random' ? `Random demo ${randomTick}/180` : runMode === 'auto' ? 'Auto-running' : 'Ready';
  }

  function jobRow(j, actions) {
    const live = !DONE.includes(j.state);
    const cells = actions ? `<td><div class="btns">${live ? btn('editjob', j.id, 'Edit') + btn('done', j.id, 'Complete') : ''}${btn('del', j.id, 'Delete', 'danger')}</div></td>` : '';
    return `<tr><td>${j.id}</td><td>${esc(j.name)}</td><td>${os.fmt(j.memMb)}</td><td>${j.remaining}/${j.burst}s</td><td>P${j.priority}</td><td>${j.device === 'NONE' ? '-' : esc(j.device)}</td><td>${j.file === 'NONE' ? '-' : esc(j.file)}</td><td>${badge(j.state)}</td>${cells}</tr>`;
  }

  function renderJobs() {
    const head = ['ID', 'Name', 'Memory', 'Left', 'Priority', 'Device', 'File', 'State'];
    const empty = 'No jobs yet. Submit one or load the samples.';
    $('#tblRecent').innerHTML = table(head, s.jobs.slice(-5).reverse().map(j => jobRow(j, false)), empty);
    $('#tblJobs').innerHTML = table([...head, 'Actions'], [...s.jobs].reverse().map(j => jobRow(j, true)), empty);
    // Device list in the job form follows installed devices
    const sel = $('#devSelect'), cur = sel.value;
    sel.innerHTML = '<option value="NONE">None</option>' + s.devices.map(d => `<option value="${esc(d.type)}">${esc(d.name)}</option>`).join('');
    sel.value = [...sel.options].some(o => o.value === cur) ? cur : 'NONE';
  }

  function renderProcesses() {
    const count = st => s.jobs.filter(j => j.state === st).length;
    $('#stateCards').innerHTML = ['READY', 'RUNNING', 'WAITING', 'TERMINATED'].map(st => statCard(st, count(st), { READY: 'In memory, waiting for the CPU', RUNNING: 'Using the CPU now', WAITING: 'Blocked on a device or file', TERMINATED: 'Finished, resources freed' }[st])).join('');
    const ready = s.jobs.filter(j => j.state === 'READY').sort((a, b) => ({ FCFS: a.arrival - b.arrival, SJF: a.remaining - b.remaining, PRIORITY: a.priority - b.priority, ROUND_ROBIN: a.seq - b.seq }[s.cpuAlgo]) || a.seq - b.seq);
    $('#readyQueue').textContent = ready.length ? ready.map(j => j.id).join('  ->  ') + `   (ordered by ${s.cpuAlgo.replace('_', ' ')})` : 'The ready queue is empty.';
    $('#tblPcb').innerHTML = table(['PID', 'Job', 'State', 'Block', 'Arrived', 'First run', 'Left', 'Priority', 'Holds'],
      s.jobs.filter(j => j.state !== 'REJECTED').map(j => `<tr><td>${j.id.replace('JOB', 'PROC')}</td><td>${esc(j.name)}</td><td>${badge(j.state)}</td><td>${j.block ? '#' + j.block : '-'}</td><td>${j.arrival}s</td><td>${j.start === null ? '-' : j.start + 's'}</td><td>${j.remaining}s</td><td>P${j.priority}</td><td>${holds(j)}</td></tr>`), 'No processes yet.');
  }

  function devCard(d, actions) {
    return `<div class="dev"><b>${esc(d.name)}</b><small>${esc(d.type)}</small>
      <div class="state ${d.holder ? 'busy' : ''}">${d.holder ? 'Busy - ' + d.holder : 'Available'}</div>
      <small>Queue: ${d.queue.length ? d.queue.join(', ') : 'empty'}</small>${actions ? '<br>' + btn('deldev', d.type, 'Remove', 'danger') : ''}</div>`;
  }
  function renderDevices() {
    $('#devMini').innerHTML = s.devices.map(d => devCard(d, false)).join('');
    $('#devFull').innerHTML = s.devices.length ? s.devices.map(d => devCard(d, true)).join('') : '<p class="hint">No devices installed. Add one to let jobs use it.</p>';
  }

  function renderChart() {
    const data = s.history.slice(-24);
    $('#chart').innerHTML = data.length ? data.map((h, i) => {
      const v = chartMode === 'used' ? (h.used / s.totalMb) * 100 : h.busy * 100;
      const tip = `T=${h.tick}s: ` + (chartMode === 'used' ? os.fmt(h.used) + ' used' : h.busy ? 'CPU busy' : 'CPU idle');
      return `<div class="col ${i === data.length - 1 ? 'last' : ''}" data-tip="${tip}"><i style="height:${Math.max(v, 3)}%"></i></div>`;
    }).join('') : '<span class="none">Press Step 1s to start recording.</span>';
  }

  function renderMemory() {
    $('#memStrip').innerHTML = s.blocks.map(b => {
      const j = b.jobId && s.jobs.find(x => x.id === b.jobId);
      return `<div class="${j ? '' : 'free'}" style="flex:${b.size};${j ? 'background:' + color(j.id) : ''}" title="Block #${b.id}: ${os.fmt(b.size)}">${j ? j.id : 'free'}</div>`;
    }).join('');
    $('#tblMem').innerHTML = table(['Block', 'Start', 'Size', 'Holder', 'Internal fragmentation', 'Actions'], s.blocks.map(b => {
      const acts = b.jobId ? btn('freeblock', b.jobId, 'Free') : btn('split', b.id, 'Split') + btn('merge', b.id, 'Merge next');
      return `<tr><td>#${b.id}</td><td>${os.fmt(b.start)}</td><td>${os.fmt(b.size)}</td><td>${b.jobId || 'free'}</td><td>${b.jobId ? os.fmt(b.waste) : '-'}</td><td><div class="btns">${acts}</div></td></tr>`;
    }), '');
    $('#ramSeg').innerHTML = RAM_OPTIONS.map(mb => `<button data-mb="${mb}" class="${mb === s.totalMb ? 'on' : ''}">${mb / 1024} GB</button>`).join('');
    document.querySelectorAll('#fitSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === s.memAlgo));
  }

  function renderScheduler(st) {
    document.querySelectorAll('#cpuSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === s.cpuAlgo));
    $('#quantum').value = s.quantum;
    $('#gantt').innerHTML = s.gantt.length ? s.gantt.map(g =>
      `<div style="flex:${g.end - g.from};background:${color(g.id)}" title="${g.id}: ${g.from}s to ${g.end}s">${g.id.slice(4)}</div>`).join('')
      : '<div class="none">The timeline appears once the CPU runs a job.</div>';
    $('#metrics').innerHTML = statCard('Avg turnaround', st.turnaround + 's') + statCard('Avg waiting', st.waiting + 's') + statCard('CPU utilisation', st.cpuUtil + '%');
  }

  function renderFiles() {
    $('#tblFiles').innerHTML = table(['File', 'Size', 'Status', 'Actions'], s.files.map(f =>
      `<tr><td>${esc(f.name)}</td><td>${f.sizeMb} MB</td><td>${f.holder ? `<span class="badge WAITING">OPEN - ${f.holder}</span>` : '<span class="badge RUNNING">AVAILABLE</span>'}</td><td><div class="btns">${btn('editfile', f.name, 'Edit')}${btn('delfile', f.name, 'Delete', 'danger')}</div></td></tr>`), 'No files yet.');
    const sel = $('#fileSelect'), cur = sel.value;
    sel.innerHTML = '<option value="NONE">None</option>' + s.files.map(f => `<option value="${esc(f.name)}">${esc(f.name)}</option>`).join('');
    sel.value = [...sel.options].some(o => o.value === cur) ? cur : 'NONE';
  }

  function renderAnalytics(st) {
    const a = os.analytics();
    $('#anCards').innerHTML = statCard('Internal fragmentation', os.fmt(a.internal), 'Wasted inside used blocks') +
      statCard('External fragmentation', os.fmt(a.external), `Free but outside the largest hole (${os.fmt(a.largest)})`) +
      statCard('Rejected jobs', `${a.rejected} (${a.rejectRate}%)`, 'No partition could hold them') +
      statCard('Throughput', a.throughput + '/s', 'Jobs finished per second');
    $('#tblUtil').innerHTML = table(['Block', 'Size', 'Used by job'], s.blocks.map(b => {
      const j = b.jobId && s.jobs.find(x => x.id === b.jobId), pct = j ? Math.round((j.memMb / b.size) * 100) : 0;
      return `<tr><td>#${b.id}</td><td>${os.fmt(b.size)}</td><td style="min-width:130px"><div class="bar dark"><i style="width:${pct}%"></i></div>${pct}%</td></tr>`;
    }), '');
    $('#tblTiming').innerHTML = table(['Job', 'Arrived', 'First run', 'Finished', 'Turnaround', 'Waiting'],
      s.jobs.filter(j => j.state === 'TERMINATED').map(j => `<tr><td>${j.id}</td><td>${j.arrival}s</td><td>${j.start === null ? '-' : j.start + 's'}</td><td>${j.done}s</td><td>${j.done - j.arrival}s</td><td>${j.done - j.arrival - j.burst}s</td></tr>`), 'Finish a job to see its timing.');
  }

  function renderTests(res) {
    const passed = res.filter(r => r.pass).length;
    $('#tblTests').innerHTML = table(['#', 'Scenario', 'Area', 'Input', 'Expected result', 'Actual result', 'Result'],
      res.map((r, i) => `<tr><td>${i + 1}</td><td>${r.name}</td><td>${r.category}</td><td>${esc(r.input || '-')}</td><td>${esc(r.expected)}</td><td>${esc(r.actual || '-')}</td><td><span class="badge ${r.pass ? 'RUNNING' : 'REJECTED'}">${r.pass ? 'PASSED' : 'FAILED'}</span></td></tr>`), '');
    $('#testSum').textContent = `${passed} / ${res.length} passed`;
  }

  function renderLog() {
    $('#tblLog').innerHTML = table(['Time', 'Tick', 'Type', 'Event', 'Why'],
      s.logs.map(l => `<tr><td>${l.t}</td><td>${l.tick}s</td><td>${l.cat}</td><td>${esc(l.msg)}</td><td>${esc(l.why)}</td></tr>`), '');
  }

  function render() {
    const st = os.stats();
    renderOverview(st); renderJobs(); renderProcesses(); renderDevices(); renderChart();
    renderMemory(); renderScheduler(st); renderFiles(); renderAnalytics(st); renderLog();
    $('#preview').textContent = os.exportText().split('Do not edit below')[0];
    try { localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch (e) { /* storage may be blocked */ }
  }

  // ---------- dialog: one reusable edit form ----------
  /** fields: [{k, label, type, value, min}] ; onSave receives {k: value}. */
  function ask(title, fields, onSave) {
    $('#dlgTitle').textContent = title;
    $('#dlgFields').innerHTML = fields.map(f => `<label>${f.label}<input name="${f.k}" type="${f.type || 'text'}" value="${esc(f.value ?? '')}" ${f.min ? `min="${f.min}"` : ''} required></label>`).join('');
    $('#dlg').showModal();
    $('#dlgForm').onsubmit = e => {
      e.preventDefault();
      const v = {}; fields.forEach(f => (v[f.k] = $('#dlgForm').elements[f.k].value));
      $('#dlg').close(); onSave(v);
    };
  }

  // ---------- actions ----------
  const actions = {
    done: id => os.complete(id),
    del: id => os.remove(id),
    freeblock: id => os.complete(id),
    editjob: id => { const j = s.jobs.find(x => x.id === id);
      ask(`Edit ${id}`, [{ k: 'name', label: 'Name', value: j.name }, { k: 'priority', label: 'Priority (1 = highest, 4 = lowest)', type: 'number', min: 1, value: j.priority }, { k: 'burst', label: 'CPU burst (s, only before first run)', type: 'number', min: 1, value: j.burst }],
        v => toast(os.editJob(id, { name: v.name.trim(), priority: Math.min(4, Math.max(1, +v.priority)), burst: +v.burst }))); },
    editfile: name => { const f = s.files.find(x => x.name === name);
      ask(`Edit ${name}`, [{ k: 'name', label: 'File name', value: f.name }, { k: 'size', label: 'Size (MB)', type: 'number', min: 1, value: f.sizeMb }],
        v => toast(os.editFile(name, { name: v.name.trim(), sizeMb: +v.size }))); },
    delfile: name => toast(os.deleteFile(name)),
    deldev: type => toast(os.removeDevice(type)),
    split: id => { const b = s.blocks.find(x => x.id === +id);
      ask(`Split block #${id} (${os.fmt(b.size)})`, [{ k: 'mb', label: 'Size of the first part (MB)', type: 'number', min: 1, value: Math.floor(b.size / 2) }],
        v => toast(os.split(+id, +v.mb))); },
    merge: id => toast(os.merge(+id)),
  };

  function loadSamples() {
    stopTimer();
    os.setRam(s.totalMb);
    PRESETS.forEach(p => os.submit({ name: p.name, memMb: p.mem * 1024, burst: p.burst, priority: p.priority, device: p.device, file: p.file }));
    toast({ ok: true, msg: 'Sample jobs loaded. Press Step 1s or Auto-run.' });
  }

  function toggleAuto() {
    const b = $('#btnAuto');
    if (timer) { stopTimer(); toast({ ok: true, msg: 'Auto-run paused. The current state is saved in this browser.' }); return; }
    if (!s.jobs.some(j => !DONE.includes(j.state))) {
      toast({ ok: false, msg: 'Nothing is ready to run. Submit a job or load samples first.' });
      return;
    }
    runMode = 'auto';
    timer = setInterval(() => {
      os.step();
      const active = s.jobs.some(j => !DONE.includes(j.state));
      if (!active && s.jobs.length) { stopTimer(); toast({ ok: true, msg: 'Auto-run finished: all jobs have reached a final state.' }); }
    }, +$('#speed').value);
    b.textContent = 'Pause';
  }

  function stopTimer() {
    if (timer) clearInterval(timer);
    timer = null; runMode = 'idle';
    if ($('#btnAuto')) $('#btnAuto').textContent = 'Auto-run';
    if ($('#btnRandom')) $('#btnRandom').textContent = 'Random demo';
  }

  function randomItem(items) { return items[Math.floor(Math.random() * items.length)]; }

  /**
   * Fully automatic demonstration: reset, submit safe random jobs, change
   * policies, advance the CPU, and stop after the queue drains. Every state
   * change is rendered and recorded in the Event log/Gantt timeline.
   */
  function runRandomDemo() {
    if (timer) { stopTimer(); toast({ ok: true, msg: 'Random demo paused. All movements remain visible in the log.' }); return; }
    os.setRam(s.totalMb); randomTick = 0; runMode = 'random';
    const names = ['Research scan', 'Compiler task', 'Report export', 'Dataset sort', 'Browser test', 'Backup job'];
    const algos = ['FCFS', 'SJF', 'ROUND_ROBIN', 'PRIORITY'];
    const memAlgos = ['FIRST_FIT', 'BEST_FIT'];
    const bursts = [2, 3, 4, 5, 6];
    const memChoices = [512, 1024, 1536, 2048, 3072, 4096, 5120, 6144];
    const tick = () => {
      randomTick++;
      const free = s.blocks.filter(b => !b.jobId), largest = Math.max(0, ...free.map(b => b.size));
      if (randomTick <= 45 && s.jobs.filter(j => !DONE.includes(j.state)).length < 5 && largest > 0 && Math.random() < .62) {
        const choices = memChoices.filter(m => m <= largest);
        if (choices.length) {
          const device = Math.random() < .45 && s.devices.length ? randomItem(s.devices).type : 'NONE';
          const file = Math.random() < .45 && s.files.length ? randomItem(s.files).name : 'NONE';
          const result = os.submit({ name: `${randomItem(names)} #${s.jobNo}`, memMb: randomItem(choices), burst: randomItem(bursts), priority: 1 + Math.floor(Math.random() * 4), device, file });
          toast(result);
        }
      }
      if (Math.random() < .35) os.set('cpuAlgo', randomItem(algos));
      if (Math.random() < .25) os.set('memAlgo', randomItem(memAlgos));
      os.step();
      const active = s.jobs.some(j => !DONE.includes(j.state));
      if ((randomTick >= 45 && !active) || randomTick >= 180) {
        stopTimer();
        toast({ ok: true, msg: `Random demo complete at T=${s.tick}s. Review the Gantt chart and Event log for every movement.` });
      }
    };
    toast({ ok: true, msg: 'Random demo started: generating jobs, changing policies, and advancing the simulation.' });
    timer = setInterval(tick, +$('#speed').value);
    $('#btnRandom').textContent = 'Pause demo';
  }

  function showView(name) {
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('show', v.id === 'v-' + name));
    document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.view === name));
    $('#crumb').textContent = name === 'storage' ? 'Save & load' : name[0].toUpperCase() + name.slice(1);
  }

  /** Download text as a file (used for the session save). */
  function download(name, text) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' })); a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  // ---------- wiring ----------
  function bind() {
    $('#nav').onclick = e => {
      const target = e.target.closest('[data-view]');
      if (!target) return;
      const url = target.dataset.pageUrl;
      if (url && document.body.dataset.page !== target.dataset.view) { window.location.href = url; return; }
      showView(target.dataset.view);
    };
    $('#btnStep').onclick = os.step;
    $('#btnAuto').onclick = toggleAuto;
    $('#btnRandom').onclick = runRandomDemo;
    $('#speed').onchange = () => {
      if (!timer) return;
      if (runMode === 'auto') { stopTimer(); toggleAuto(); }
      else toast({ ok: true, msg: 'New speed will be used the next time Random demo starts.' });
    };
    $('#btnReset').onclick = () => { stopTimer(); os.setRam(s.totalMb); toast({ ok: true, msg: 'Simulation reset.' }); };
    $('#btnSample').onclick = loadSamples;
    $('#btnClear').onclick = os.clearFinished;
    $('#btnCompact').onclick = () => toast(os.compact());
    $('#btnTests').onclick = () => renderTests(runAllTests());
    $('#btnAddDev').onclick = () => ask('Add device', [{ k: 'name', label: 'Device name', value: 'Projector' }, { k: 'type', label: 'Type (short word)', value: 'PROJECTOR' }], v => toast(os.addDevice(v.name.trim(), v.type)));
    $('#dlgCancel').onclick = () => $('#dlg').close();
    $('#chartMode').onclick = e => { if (!e.target.dataset.m) return; chartMode = e.target.dataset.m; document.querySelectorAll('#chartMode button').forEach(b => b.classList.toggle('on', b === e.target)); renderChart(); };
    $('#ramSeg').onclick = e => e.target.dataset.mb && os.setRam(+e.target.dataset.mb);
    $('#fitSeg').onclick = e => e.target.dataset.v && os.set('memAlgo', e.target.dataset.v);
    $('#cpuSeg').onclick = e => e.target.dataset.v && os.set('cpuAlgo', e.target.dataset.v);
    $('#quantum').onchange = e => os.set('quantum', Math.max(1, +e.target.value || 2));

    // Save / load text file
    $('#btnSave').onclick = () => { download(`ump-lab-session-T${s.tick}.txt`, os.exportText()); toast({ ok: true, msg: 'Session saved as a .txt file.' }); };
    $('#fileLoad').onchange = e => {
      const f = e.target.files[0]; if (!f) return;
      const r = new FileReader(); r.onload = () => toast(os.importText(r.result)); r.readAsText(f); e.target.value = '';
    };
    $('#btnWipe').onclick = () => { try { localStorage.removeItem(STORE_KEY); } catch (e) { /* ignore */ } toast({ ok: true, msg: 'Browser copy erased. Your saved .txt files are untouched.' }); };

    // One click handler for every table/card button, plus "Open ..." shortcuts in the guide
    document.addEventListener('click', e => {
      const { act, id, go } = e.target.dataset;
      if (act && actions[act]) actions[act](id);
      if (go) showView(go);
    });

    // Job form + presets
    const form = $('#jobForm');
    $('#presets').innerHTML = PRESETS.map((p, i) => `<button type="button" data-i="${i}">${p.label}</button>`).join('');
    $('#presets').onclick = e => {
      const p = PRESETS[e.target.dataset.i]; if (!p) return;
      Object.entries({ name: p.name, mem: p.mem, unit: p.unit, burst: p.burst, priority: p.priority, device: p.device, file: p.file }).forEach(([k, v]) => (form.elements[k].value = v));
    };
    form.onsubmit = e => {
      e.preventDefault();
      const f = form.elements, mem = +f.mem.value * (f.unit.value === 'GB' ? 1024 : 1);
      toast(os.submit({ name: f.name.value.trim(), memMb: mem, burst: +f.burst.value, priority: +f.priority.value, device: f.device.value, file: f.file.value }));
    };
    $('#fileForm').onsubmit = e => {
      e.preventDefault(); const f = e.target.elements, r = os.createFile(f.name.value.trim(), +f.size.value);
      toast(r); if (r.ok) f.name.value = '';
    };
  }

  // ---------- start-up ----------
  try { const saved = JSON.parse(localStorage.getItem(STORE_KEY)); if (saved && saved.blocks) os.load(saved); else throw 0; }
  catch (e) { /* first visit: start with samples so the dashboard is not empty */ }
  os.subscribe(render);
  bind();
  showView(document.body.dataset.page || 'dashboard');
  renderTests(runAllTests());
  if (!s.jobs.length && !s.tick) loadSamples(); else render();
  window.addEventListener('beforeunload', () => { if (timer) clearInterval(timer); });
})();

/**
 * engine.js - Simulation core (ported from the Java classes).
 * Pure logic, no DOM access, so the UI can be changed freely.
 *
 *   MemoryManager  -> dynamic partitions, First-Fit / Best-Fit, deallocation, compaction
 *   CpuScheduler   -> FCFS, SJF, Round Robin, Priority (pick())
 *   DeviceManager  -> exclusive devices with FIFO wait queues
 *   Job records    -> act as the Process Control Block (PCB)
 */
const UMOS = (() => {
  // Peripheral devices shared by the lab (edit here to add more).
  const DEVICES = [
    { type: 'PRINTER', name: 'HP LaserJet Pro 400' },
    { type: 'SCANNER', name: 'Epson Perfection V39' },
    { type: 'DISK',    name: 'Samsung 980 NVMe SSD' },
    { type: 'USB',     name: 'Kingston USB 3.0 Flash' },
  ];

  // Files that exist in the lab directory at start-up.
  const DEFAULT_FILES = [
    { name: 'student_report.pdf', sizeMb: 2 },
    { name: 'lab_assignment.java', sizeMb: 1 },
    { name: 'lab_dataset.csv', sizeMb: 15 },
  ];

  /** Start with one contiguous FREE block; dynamic partitions are created on demand. */
  function partition(total) {
    return [{ id: 1, start: 0, size: total, jobId: null, waste: 0 }];
  }

  function createEngine(totalMb = 16384) {
    const listeners = [];
    const s = {
      totalMb, blocks: partition(totalMb), jobs: [], logs: [], gantt: [], history: [],
      devices: DEVICES.map(d => ({ ...d, holder: null, queue: [] })),
      files: DEFAULT_FILES.map(f => ({ ...f, holder: null, queue: [] })),
      tick: 0, seq: 0, jobNo: 1, busyTicks: 0,
      memAlgo: 'FIRST_FIT', cpuAlgo: 'FCFS', quantum: 2, quantumUsed: 0,
    };

    // ---------- helpers ----------
    const emit = () => listeners.forEach(fn => fn(s));
    const job = id => s.jobs.find(j => j.id === id);
    const usedMb = () => s.blocks.filter(b => b.jobId).reduce((t, b) => { const j = job(b.jobId); return t + (j ? j.memMb : 0); }, 0);
    const fmt = mb => (mb >= 1024 ? +(mb / 1024).toFixed(1) + ' GB' : mb + ' MB');
    const fail = msg => ({ ok: false, msg });
    const ok = msg => ({ ok: true, msg });

    function log(cat, msg, why = '') {
      s.logs.unshift({ t: new Date().toLocaleTimeString('en-GB'), tick: s.tick, cat, msg, why });
      if (s.logs.length > 200) s.logs.pop();
    }

    // ---------- memory ----------
    function allocate(j) {
      const fits = s.blocks.filter(b => !b.jobId && b.size >= j.memMb);
      if (!fits.length) return null;
      // First-Fit takes the first suitable hole; Best-Fit takes the smallest suitable hole.
      const hole = s.memAlgo === 'FIRST_FIT' ? fits[0] : fits.reduce((a, b) => (b.size < a.size ? b : a));
      const i = s.blocks.indexOf(hole);
      const allocated = { ...hole, size: j.memMb, jobId: j.id, waste: 0 };
      const remainder = hole.size - j.memMb;
      const replacement = remainder > 0
        ? [allocated, { id: 0, start: hole.start + j.memMb, size: remainder, jobId: null, waste: 0 }]
        : [allocated];
      s.blocks.splice(i, 1, ...replacement);
      renumber();
      return s.blocks.find(b => b.jobId === j.id);
    }

    function mergeAdjacentFree() {
      for (let i = 0; i < s.blocks.length - 1;) {
        const a = s.blocks[i], b = s.blocks[i + 1];
        if (!a.jobId && !b.jobId) {
          s.blocks.splice(i, 2, { ...a, size: a.size + b.size, waste: 0 });
        } else i++;
      }
      renumber();
    }

    function freeMemory(jobId) {
      const i = s.blocks.findIndex(x => x.jobId === jobId);
      if (i < 0) return 0;
      const released = s.blocks[i].size;
      s.blocks[i].jobId = null;
      s.blocks[i].waste = 0;
      mergeAdjacentFree();
      return released;
    }

    // ---------- devices and files (mutual exclusion) ----------
    // Devices and files are both "resources": one holder at a time, FIFO wait queue.
    const resources = () => [...s.devices, ...s.files];
    const wants = (r, j) => (r.type ? j.device === r.type : j.file === r.name);
    const label = r => r.name;

    /** Lock every resource the job needs, or queue on the first busy one. */
    function acquire(j) {
      const needed = resources().filter(r => wants(r, j));
      const busy = needed.find(r => r.holder && r.holder !== j.id);
      if (busy) {
        if (!busy.queue.includes(j.id)) busy.queue.push(j.id);
        log('DEVICE', `${j.id} waits for ${label(busy)}`, `Held by ${busy.holder}; job moved to WAITING.`);
        return false;
      }
      needed.filter(r => !r.holder).forEach(r => { r.holder = j.id; log('DEVICE', `${j.id} locked ${label(r)}`, 'Exclusive access granted.'); });
      return true;
    }

    /** Give back everything the job holds; hand each resource to the next in its queue. */
    function release(j) {
      resources().forEach(r => {
        r.queue = r.queue.filter(id => id !== j.id);
        if (r.holder !== j.id) return;
        const next = job(r.queue.shift());
        r.holder = next ? next.id : null;
        if (next) { // I/O completion: waiting job becomes READY again
          next.state = 'READY'; next.seq = ++s.seq;
          log('DEVICE', `${label(r)} handed to ${next.id}`, 'Waiting job moved back to READY.');
        }
      });
    }

    // ---------- file manager ----------
    function createFile(name, sizeMb) {
      if (!name || !(sizeMb > 0)) return fail('Enter a file name and a size above 0 MB.');
      if (s.files.some(f => f.name.toLowerCase() === name.toLowerCase())) return fail(`"${name}" already exists.`);
      s.files.push({ name, sizeMb, holder: null, queue: [] });
      log('FILE', `File "${name}" created`, `${sizeMb} MB entry added to the directory.`);
      emit(); return ok(`"${name}" created.`);
    }

    function deleteFile(name) {
      const f = s.files.find(x => x.name === name);
      if (!f) return fail('File not found.');
      if (f.holder) return fail(`"${name}" is open by ${f.holder} and cannot be deleted.`);
      s.files = s.files.filter(x => x !== f);
      log('FILE', `File "${name}" deleted`, 'Directory entry removed.');
      emit(); return ok(`"${name}" deleted.`);
    }

    // ---------- job lifecycle ----------
    /** Validate, allocate RAM and create the PCB in READY state. */
    function submit({ name, memMb, burst, priority = 2, device = 'NONE', file = 'NONE' }) {
      memMb = Math.round(memMb); burst = Math.round(burst);
      if (!String(name ?? '').trim()) return fail('Job name cannot be blank.');
      if (!(memMb > 0) || !(burst > 0)) return fail('Memory and burst time must be greater than 0.');
      const j = {
        id: 'JOB-' + String(s.jobNo++).padStart(3, '0'), name: String(name).trim(), memMb, burst,
        remaining: burst, priority, device, file, arrival: s.tick, seq: ++s.seq,
        state: 'READY', start: null, done: null, block: null,
      };
      s.jobs.push(j);
      if (memMb > s.totalMb) { j.state = 'REJECTED'; log('JOB', `${j.id} rejected`, `${fmt(memMb)} exceeds total RAM (${fmt(s.totalMb)}).`); emit(); return fail(`${j.id} needs more than the ${fmt(s.totalMb)} installed.`); }
      const b = allocate(j);
      if (!b) {
        j.state = 'REJECTED';
        const largestFree = Math.max(0, ...s.blocks.filter(x => !x.jobId).map(x => x.size));
        const reason = largestFree ? `The largest free hole is ${fmt(largestFree)}, but this job needs ${fmt(memMb)}.` : 'All RAM is currently allocated.';
        const freeTotal = s.blocks.filter(x => !x.jobId).reduce((t, x) => t + x.size, 0);
        const detail = largestFree && freeTotal >= memMb ? `${reason} Total free memory is ${fmt(freeTotal)}, so this is external fragmentation.` : reason;
        log('MEMORY', `${j.id} rejected`, detail);
        emit();
        return fail(`Job rejected: ${reason} Complete or delete a job, reset the simulation, or choose a smaller memory request.`);
      }
      j.block = b.id;
      const remainder = s.blocks.find(x => x.start === b.start + j.memMb && !x.jobId);
      log('MEMORY', `${j.id} allocated ${fmt(j.memMb)} in block #${b.id} (${s.memAlgo.replace('_', '-')})`, remainder ? `Remaining free portion: ${fmt(remainder.size)}.` : 'The selected free block was used completely.');
      emit();
      return ok(`${j.id} admitted to block #${b.id}.`);
    }

    /** Mark finished and reclaim RAM + devices. */
    function finish(j) {
      const freed = freeMemory(j.id);
      release(j);
      j.state = 'TERMINATED'; j.remaining = 0; j.done = s.tick; j.block = null;
      log('CPU', `${j.id} terminated`, `${fmt(freed)} RAM freed. Turnaround ${s.tick - j.arrival}s.`);
    }

    const complete = id => { const j = job(id); if (j && j.state !== 'TERMINATED' && j.state !== 'REJECTED') { finish(j); emit(); } };

    function remove(id) {
      const j = job(id); if (!j) return;
      if (j.state !== 'TERMINATED' && j.state !== 'REJECTED') { freeMemory(id); release(j); }
      s.jobs = s.jobs.filter(x => x.id !== id);
      log('JOB', `${id} deleted`, 'Resources reclaimed and record removed.');
      emit();
    }

    function clearFinished() { s.jobs = s.jobs.filter(j => j.state !== 'TERMINATED' && j.state !== 'REJECTED'); emit(); }

    // ---------- CPU scheduling ----------
    /** Choose the next READY job according to the active algorithm. */
    function pick(ready) {
      const key = { FCFS: j => j.arrival, SJF: j => j.remaining, PRIORITY: j => j.priority, ROUND_ROBIN: j => j.seq }[s.cpuAlgo];
      return [...ready].sort((a, b) => key(a) - key(b) || a.seq - b.seq)[0];
    }

    /** Give the CPU to a job; returns false if it must wait for a device. */
    function dispatch(j) {
      if (!acquire(j)) { j.state = 'WAITING'; return false; }
      j.state = 'RUNNING'; s.quantumUsed = 0;
      if (j.start === null) j.start = s.tick - 1;
      log('CPU', `${j.id} dispatched (${s.cpuAlgo})`, 'Context switch to RUNNING.');
      return true;
    }

    /** Advance the simulation by one second. */
    function step() {
      s.tick++;
      let run = s.jobs.find(j => j.state === 'RUNNING');
      while (!run) {
        const next = pick(s.jobs.filter(j => j.state === 'READY'));
        if (!next) break;
        if (dispatch(next)) run = next;
      }
      if (run) {
        const last = s.gantt[s.gantt.length - 1];
        if (last && last.id === run.id && last.end === s.tick - 1) last.end = s.tick;
        else s.gantt.push({ id: run.id, name: run.name, from: s.tick - 1, end: s.tick });
        run.remaining--; s.quantumUsed++; s.busyTicks++;
        if (run.remaining <= 0) finish(run);
        else if (s.cpuAlgo === 'ROUND_ROBIN' && s.quantumUsed >= s.quantum && s.jobs.some(j => j.state === 'READY')) {
          run.state = 'READY'; run.seq = ++s.seq; // back of the queue
          log('CPU', `${run.id} quantum expired`, `Preempted after ${s.quantum}s.`);
        }
      }
      s.jobs.forEach(j => { if (j.state === 'READY') j.waited = (j.waited || 0) + 1; });
      s.history.push({ tick: s.tick, used: usedMb(), busy: run ? 1 : 0 });
      if (s.history.length > 60) s.history.shift();
      emit();
    }

    // ---------- adjustable memory (split / merge partitions) ----------
    /** Re-number blocks 1..n after the layout changes and keep each job's block id in sync. */
    function renumber() {
      s.blocks.forEach((b, i) => { b.id = i + 1; const j = b.jobId && job(b.jobId); if (j) j.block = b.id; });
    }

    /** Cut a FREE block into two: the first part gets `mb` megabytes. */
    function split(id, mb) {
      const i = s.blocks.findIndex(b => b.id === id), b = s.blocks[i];
      mb = Math.round(mb);
      if (!b) return fail('Block not found.');
      if (b.jobId) return fail('Free the block first, then split it.');
      if (!(mb > 0 && mb < b.size)) return fail(`Enter a size between 1 and ${b.size - 1} MB.`);
      s.blocks.splice(i, 1, { ...b, size: mb }, { id: 0, start: b.start + mb, size: b.size - mb, jobId: null, waste: 0 });
      renumber(); log('MEMORY', `Block #${id} split`, `${fmt(mb)} + ${fmt(b.size - mb)}.`); emit();
      return ok(`Block #${id} split in two.`);
    }

    /** Join a FREE block with the FREE block that follows it. */
    function merge(id) {
      const i = s.blocks.findIndex(b => b.id === id), a = s.blocks[i], n = s.blocks[i + 1];
      if (!a || a.jobId) return fail('Only a free block can be merged.');
      if (!n || n.jobId) return fail('The block after it must also be free.');
      s.blocks.splice(i, 2, { ...a, size: a.size + n.size });
      renumber(); log('MEMORY', `Blocks #${id} and #${id + 1} merged`, `New free block of ${fmt(a.size + n.size)}.`); emit();
      return ok('Blocks merged.');
    }

    // ---------- editing ----------
    /** Change name/priority any time; burst only before the job first runs. */
    function editJob(id, { name, priority, burst }) {
      const j = job(id);
      if (!j || ['TERMINATED', 'REJECTED'].includes(j.state)) return fail('Finished jobs cannot be edited.');
      if (burst !== j.burst && j.start !== null) return fail('Burst time can only change before the job first runs.');
      if (burst !== j.burst) j.burst = j.remaining = burst;
      j.name = name || j.name; j.priority = priority;
      log('JOB', `${id} edited`, `Name "${j.name}", priority ${priority}, burst ${j.burst}s.`); emit();
      return ok(`${id} updated.`);
    }

    function editFile(old, { name, sizeMb }) {
      const f = s.files.find(x => x.name === old);
      if (!f) return fail('File not found.');
      if (f.holder) return fail(`"${old}" is open by ${f.holder}; try again when it is released.`);
      if (!name || !(sizeMb > 0)) return fail('Enter a name and a size above 0 MB.');
      if (name !== old && s.files.some(x => x.name.toLowerCase() === name.toLowerCase())) return fail(`"${name}" already exists.`);
      s.jobs.forEach(j => { if (j.file === old) j.file = name; });
      Object.assign(f, { name, sizeMb });
      log('FILE', `File "${old}" edited`, `Now "${name}", ${sizeMb} MB.`); emit();
      return ok('File updated.');
    }

    function addDevice(name, type) {
      type = String(type).trim().toUpperCase().replace(/\s+/g, '_');
      if (!name || !type) return fail('Enter a device name and a type.');
      if (type === 'NONE' || s.devices.some(d => d.type === type)) return fail(`Type ${type} is already used.`);
      s.devices.push({ type, name, holder: null, queue: [] });
      log('DEVICE', `${name} installed`, `New device type ${type}.`); emit();
      return ok(`${name} added.`);
    }

    function removeDevice(type) {
      const d = s.devices.find(x => x.type === type);
      if (!d) return fail('Device not found.');
      if (d.holder) return fail(`${d.name} is in use by ${d.holder}.`);
      s.jobs.forEach(j => { if (j.device === type && !['TERMINATED', 'REJECTED'].includes(j.state)) j.device = 'NONE'; });
      s.devices = s.devices.filter(x => x !== d);
      log('DEVICE', `${d.name} removed`, 'Waiting jobs no longer need it.'); emit();
      return ok(`${d.name} removed.`);
    }

    // ---------- save / load as plain text ----------
    /** Human-readable report followed by the machine data block used for loading. */
    function exportText() {
      const holds = j => [...s.devices, ...s.files].filter(r => r.holder === j.id).map(r => r.name).join(', ') || '-';
      const L = ['UMP LAB RESOURCE MANAGER - SESSION REPORT', 'Saved: ' + new Date().toLocaleString('en-GB'),
        `Simulation time: ${s.tick}s | RAM: ${fmt(s.totalMb)} | Memory policy: ${s.memAlgo} | CPU policy: ${s.cpuAlgo} (quantum ${s.quantum}s)`, '',
        '== JOBS =='].concat(s.jobs.map(j => `${j.id} | ${j.name} | ${fmt(j.memMb)} | burst ${j.burst}s | left ${j.remaining}s | P${j.priority} | ${j.state} | holds: ${holds(j)}`),
        ['', '== MEMORY BLOCKS =='], s.blocks.map(b => `#${b.id} | start ${b.start} MB | ${fmt(b.size)} | ${b.jobId || 'free'}`),
        ['', '== FILES =='], s.files.map(f => `${f.name} | ${f.sizeMb} MB | ${f.holder ? 'open by ' + f.holder : 'available'}`),
        ['', '== DEVICES =='], s.devices.map(d => `${d.name} (${d.type}) | ${d.holder ? 'busy: ' + d.holder : 'available'} | queue: ${d.queue.join(', ') || 'empty'}`),
        ['', '== LATEST EVENTS =='], s.logs.slice(0, 20).map(l => `[${l.t}] T${l.tick}s ${l.cat}: ${l.msg}`),
        ['', 'Do not edit below this line - it is used to load the session again.', '---BEGIN DATA---', JSON.stringify(s), '---END DATA---']);
      return L.join('\n');
    }

    function importText(text) {
      const m = String(text).match(/---BEGIN DATA---\r?\n([\s\S]*?)\r?\n---END DATA---/);
      if (!m) return fail('This file is not a saved session from this simulator.');
      try {
        const d = JSON.parse(m[1]);
        if (!Array.isArray(d.blocks) || !Array.isArray(d.jobs) || !Array.isArray(d.devices) || !Array.isArray(d.files)) throw new Error('shape');
        Object.assign(s, d); log('SYSTEM', 'Session loaded from file', `${s.jobs.length} jobs restored.`); emit();
        return ok('Session loaded.');
      } catch (e) { return fail('The saved data is damaged and could not be loaded.'); }
    }

    /** Extra numbers for the Analytics page. */
    function analytics() {
      const free = s.blocks.filter(b => !b.jobId), largest = Math.max(0, ...free.map(b => b.size));
      const freeTotal = free.reduce((t, b) => t + b.size, 0), rejected = s.jobs.filter(j => j.state === 'REJECTED').length;
      return {
        internal: s.blocks.reduce((t, b) => t + (b.jobId ? b.waste : 0), 0), external: freeTotal - largest, largest,
        rejected, rejectRate: s.jobs.length ? Math.round((rejected / s.jobs.length) * 100) : 0,
        throughput: s.tick ? (s.jobs.filter(j => j.state === 'TERMINATED').length / s.tick).toFixed(2) : '0.00',
      };
    }

    // ---------- configuration ----------
    function compact() {
      const held = s.blocks.filter(b => b.jobId), free = s.blocks.filter(b => !b.jobId);
      if (free.length <= 1) return fail('Memory is already contiguous.');
      let addr = 0;
      const out = held.map((b, i) => { const n = { ...b, id: i + 1, start: addr }; addr += b.size; job(b.jobId).block = n.id; return n; });
      out.push({ id: out.length + 1, start: addr, size: s.totalMb - addr, jobId: null, waste: 0 });
      s.blocks = out;
      log('MEMORY', 'Compaction complete', `${free.length} free holes merged into one ${fmt(s.totalMb - addr)} block.`);
      emit();
      return ok('Free space merged into one block.');
    }

    function setRam(mb) {
      Object.assign(s, { totalMb: mb, blocks: partition(mb), jobs: [], gantt: [], history: [], tick: 0, busyTicks: 0, jobNo: 1 });
      resources().forEach(r => { r.holder = null; r.queue = []; });
      log('SYSTEM', `RAM set to ${fmt(mb)}`, 'Memory repartitioned; simulation restarted.');
      emit();
    }

    function set(key, value) { s[key] = value; log('SYSTEM', `${key} = ${value}`); emit(); }

    function stats() {
      const done = s.jobs.filter(j => j.state === 'TERMINATED');
      const avg = f => (done.length ? (done.reduce((t, j) => t + f(j), 0) / done.length).toFixed(1) : '-');
      return {
        used: usedMb(), free: s.totalMb - usedMb(), done: done.length,
        turnaround: avg(j => j.done - j.arrival), waiting: avg(j => j.done - j.arrival - j.burst),
        cpuUtil: s.tick ? Math.round((s.busyTicks / s.tick) * 100) : 0,
      };
    }

    log('SYSTEM', 'Simulator ready', `${fmt(totalMb)} RAM, ${DEVICES.length} devices.`);
    return {
      state: s, fmt, stats, subscribe: fn => listeners.push(fn),
      submit, complete, remove, clearFinished, step, compact, setRam, set, createFile, deleteFile,
      split, merge, editJob, editFile, addDevice, removeDevice, exportText, importText, analytics,
      load: saved => { Object.assign(s, saved); emit(); },
    };
  }

  return { createEngine, DEVICES };
})();

/**
 * Minimal JavaScript backend for UMP Lab Resource Manager.
 * Uses Node's built-in modules only: no framework, package manager, or build step.
 * Run: node server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 8080);
const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };
const started = new Date().toISOString();

function json(res, status, value) {
  const body = JSON.stringify(value, null, 2);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function safeFile(urlPath) {
  const decoded = decodeURIComponent(urlPath === '/' ? '/index.html' : urlPath);
  const file = path.normalize(path.join(ROOT, decoded));
  return file.startsWith(ROOT) ? file : null;
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/api/health') return json(res, 200, { ok: true, service: 'UMP Lab Resource Manager', runtime: 'Node.js', started });
  if (url.pathname === '/api/project-info') return json(res, 200, {
    name: 'UMP Lab Resource Manager', version: '2.1.0', languages: ['HTML', 'CSS', 'JavaScript'],
    pages: ['dashboard','jobs','processes','memory','scheduler','devices','files','analytics','tests','log','storage','guide'],
    features: ['live calculations', 'alerts', 'auto-run', 'random demo with movement log', 'readable TXT export/import', 'automated tests', 'draw.io architecture diagram']
  });
  if (url.pathname === '/api/time') return json(res, 200, { now: new Date().toISOString(), unix: Date.now() });
  const file = safeFile(url.pathname);
  if (!file) return json(res, 403, { ok: false, error: 'Forbidden path' });
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) return json(res, 404, { ok: false, error: 'Not found' });
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  });
});
server.listen(PORT, '0.0.0.0', () => console.log(`UMP Lab backend running at http://0.0.0.0:${PORT}`));
